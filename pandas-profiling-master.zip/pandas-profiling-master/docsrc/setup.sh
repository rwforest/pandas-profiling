#!/usr/bin/env bash
cd source
ln -s ../../README.md
