Profile Report
**************

=============
ProfileReport
=============

.. currentmodule:: pandas_profiling
.. toctree::

.. autosummary::
   :toctree: _autosummary

   profile_report.ProfileReport
   serialize_report.SerializeReport
   config.Config
