=========
Changelog
=========

.. include:: changelog/v3_1_1.rst

.. include:: changelog/v3_1_0.rst

.. include:: changelog/v3_0_0.rst

.. include:: changelog/v2_13_0.rst

.. include:: changelog/v2_12_0.rst

.. include:: changelog/v2_11_0.rst

.. include:: changelog/v2_10_1.rst

.. include:: changelog/v2_10_0.rst

.. include:: changelog/v2_9_0.rst

.. include:: changelog/v2_9_0rc1.rst

.. include:: changelog/v2_8_0.rst

.. include:: changelog/v2_7_1.rst

.. include:: changelog/v2_7_0.rst

Prior to v2.7.0
---------------

Previously, there was no explicit changelog. However, changes were included in the release description on Github, which you can find `at this page <https://github.com/pandas-profiling/pandas-profiling/releases>`_.