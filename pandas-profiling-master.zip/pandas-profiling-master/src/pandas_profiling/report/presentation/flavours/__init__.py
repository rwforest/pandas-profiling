from pandas_profiling.report.presentation.flavours.flavours import (
    HTMLReport,
    WidgetReport,
)

__all__ = [
    "HTMLReport",
    "WidgetReport",
]
